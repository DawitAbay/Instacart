document.querySelector(".cardbtn").addEventListener("click",function(){
    window.open("signup.html","_blank")
})